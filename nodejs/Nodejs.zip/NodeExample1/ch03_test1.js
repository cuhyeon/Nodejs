/*jslint devel: true */
/* eslint-disable no-console */
/*eslint no-undef: "error"*/
/*eslint-env node*/
var age = 20;
console.log('나이 : %d', age);

var name = '소녀시대';
console.log('이름 : %s', name);