/*jslint devel: true */
/* eslint-disable no-console */
/*eslint no-undef: "error"*/
/*eslint-env node*/
console.dir(process.env);
console.log('OS 환경변수의 값 : ' + process.env['OS']);