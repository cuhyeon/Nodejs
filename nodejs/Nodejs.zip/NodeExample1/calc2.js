/*jslint devel: true */
/*eslint-disable no-console */
/*eslint no-undef: "error"*/
/*eslint-env node*/
var calc = {};

calc.add = function(a,b) {
    return a+b;
};

module.exports = calc;