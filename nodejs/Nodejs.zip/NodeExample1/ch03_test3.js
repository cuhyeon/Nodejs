/*jslint devel: true */
/*eslint-disable no-console */
/*eslint no-undef: "error"*/
/*eslint-env node*/
function add(a,b) {
    return a+b;
}

var result = add(10, 10);

console.log('더하기 (10,10) : %d', result);